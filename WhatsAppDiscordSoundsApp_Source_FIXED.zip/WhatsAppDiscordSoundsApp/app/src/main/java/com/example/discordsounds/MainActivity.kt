package com.example.discordsounds

import android.app.Activity
import android.media.MediaPlayer
import android.os.Bundle
import android.provider.Settings
import android.content.Intent
import android.view.Gravity
import android.widget.*
import java.time.LocalDate

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var selectedPack = "Standard"
    private lateinit var status: TextView
    private lateinit var messageSpinner: Spinner
    private lateinit var callSpinner: Spinner
    private var soundNames: List<String> = emptyList()

    private fun seasonalPack(): String {
        val d = LocalDate.now()
        return when {
            d.monthValue == 10 || (d.monthValue == 11 && d.dayOfMonth == 1) -> "Halloween"
            d.monthValue == 12 || (d.monthValue == 1 && d.dayOfMonth <= 7) -> "Winter"
            else -> "Standard"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("sound_settings", MODE_PRIVATE)
        selectedPack = prefs.getString("pack", seasonalPack()) ?: seasonalPack()
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        scroll.addView(page)
        page.addView(TextView(this).apply { text = "Discord Sounds for WhatsApp"; textSize = 24f })
        page.addView(TextView(this).apply {
            text = "בחר חבילת צלילים וצליל נפרד להודעות ולשיחות. כדי שהצליל החלופי יעבוד, צריך לאפשר גישה להתראות ולהשתיק את צלילי WhatsApp המקוריים בהגדרות WhatsApp."
            textSize = 15f; setPadding(0, 12, 0, 16)
        })
        status = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 12) }
        page.addView(status)
        val packSpinner = Spinner(this)
        val packs = listOf("Standard", "Halloween", "Winter", "Extras")
        packSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, packs)
        packSpinner.setSelection(packs.indexOf(selectedPack).coerceAtLeast(0))
        page.addView(TextView(this).apply { text = "חבילת צלילים"; textSize = 18f })
        page.addView(packSpinner)
        page.addView(TextView(this).apply { text = "צליל להודעות"; textSize = 18f; setPadding(0, 12, 0, 4) })
        messageSpinner = Spinner(this); page.addView(messageSpinner)
        page.addView(TextView(this).apply { text = "צליל לשיחות / התראת שיחה"; textSize = 18f; setPadding(0, 12, 0, 4) })
        callSpinner = Spinner(this); page.addView(callSpinner)
        packSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedPack = packs[position]; loadSounds(prefs)
            }
        }
        page.addView(Button(this).apply { text = "שמור את הבחירות"; setOnClickListener {
            val msg = soundNames.getOrNull(messageSpinner.selectedItemPosition) ?: soundNames.firstOrNull().orEmpty()
            val call = soundNames.getOrNull(callSpinner.selectedItemPosition) ?: msg
            prefs.edit().putString("pack", selectedPack).putString("message_sound", msg).putString("call_sound", call).apply()
            status.text = "נשמר: $selectedPack | הודעות: $msg | שיחות: $call"
            Toast.makeText(this@MainActivity, "הבחירות נשמרו", Toast.LENGTH_SHORT).show()
        } })
        page.addView(Button(this).apply { text = "▶ השמע הודעה לדוגמה"; setOnClickListener { play(selectedPack, soundNames.getOrNull(messageSpinner.selectedItemPosition)) } })
        page.addView(Button(this).apply { text = "▶ השמע שיחה לדוגמה"; setOnClickListener { play(selectedPack, soundNames.getOrNull(callSpinner.selectedItemPosition)) } })
        page.addView(Button(this).apply { text = "1. הפעל גישה להתראות"; setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } })
        page.addView(Button(this).apply { text = "2. פתח הגדרות התראות של WhatsApp"; setOnClickListener {
            try { startActivity(Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", "com.whatsapp")) }
            catch (_: Exception) { Toast.makeText(this@MainActivity, "פתח ידנית: הגדרות Android ← אפליקציות ← WhatsApp ← התראות", Toast.LENGTH_LONG).show() }
        } })
        page.addView(TextView(this).apply {
            text = "חשוב לדעת:\n• האפליקציה משמיעה צליל חלופי כאשר Android מדווח לה על התראת WhatsApp.\n• כדי למנוע צליל כפול, צריך להשתיק את צלילי WhatsApp המקוריים. אל תכבה את ההתראות עצמן.\n• זיהוי התראות שיחה אפשרי בחלק מהמכשירים; מענה, ניתוק, השתקת מיקרופון והעברה להמתנה אינם נחשפים באופן אמין לאפליקציה חיצונית.\n• אין כאן גישה להודעות מלאות, לשיחות, לסטטוסים או לגיבויים."
            textSize = 13f; setPadding(0, 20, 0, 12)
        })
        setContentView(scroll)
        loadSounds(prefs)
    }

    private fun names(pack: String): List<String> = try { assets.list("sounds/$pack")?.filter { it.endsWith(".mp3") }?.sorted() ?: emptyList() } catch (_: Exception) { emptyList() }

    private fun loadSounds(prefs: android.content.SharedPreferences) {
        soundNames = names(selectedPack)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, soundNames)
        messageSpinner.adapter = adapter; callSpinner.adapter = adapter
        val msg = prefs.getString("message_sound", "") ?: ""
        val call = prefs.getString("call_sound", "") ?: ""
        messageSpinner.setSelection(soundNames.indexOf(msg).takeIf { it >= 0 } ?: soundNames.indexOfFirst { it.contains("message", true) }.coerceAtLeast(0))
        callSpinner.setSelection(soundNames.indexOf(call).takeIf { it >= 0 } ?: soundNames.indexOfFirst { it.contains("call", true) }.coerceAtLeast(0))
        status.text = "חבילה: $selectedPack | ${soundNames.size} צלילים זמינים"
    }

    private fun play(pack: String, file: String?) {
        if (file == null) return
        try {
            player?.release()
            val afd = assets.openFd("sounds/$pack/$file")
            player = MediaPlayer().apply { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length); prepare(); start(); setOnCompletionListener { it.release(); player = null } }
            afd.close()
        } catch (e: Exception) { Toast.makeText(this, "לא ניתן לנגן: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
