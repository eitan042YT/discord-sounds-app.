package com.example.discordsounds

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class WhatsAppNotificationListener : NotificationListenerService() {
    private var player: MediaPlayer? = null
    private val seen = LinkedHashSet<String>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return
        // Avoid replaying the same ongoing notification when WhatsApp updates it.
        val key = sbn.key
        if (!seen.add(key)) return
        if (seen.size > 300) seen.clear()
        val prefs = getSharedPreferences("sound_settings", MODE_PRIVATE)
        val isCall = sbn.notification.category == android.app.Notification.CATEGORY_CALL
        val pack = prefs.getString("pack", "Standard") ?: "Standard"
        val file = prefs.getString(if (isCall) "call_sound" else "message_sound", null) ?: return
        playAsset("sounds/$pack/$file")
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) { seen.remove(sbn.key) }

    private fun playAsset(path: String) {
        try {
            player?.release()
            val afd = assets.openFd(path)
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { it.release(); if (player === it) player = null }
                prepareAsync()
            }
            afd.close()
        } catch (e: Exception) { Log.e("WhatsAppSound", "Could not play $path", e) }
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
