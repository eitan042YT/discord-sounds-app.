WhatsApp Discord Sounds – פרויקט Android
========================================

זהו פרויקט מקור לאפליקציית Android, לא קובץ APK מוכן. בסביבת היצירה אין Android SDK/Gradle ולכן לא ניתן לקמפל כאן APK אמיתי.

מה האפליקציה עושה:
- מציגה חבילות Standard / Halloween / Winter / Extras.
- בוחרת חבילה מומלצת לפי תאריך: Halloween באוקטובר ועד 1 בנובמבר; Winter בדצמבר ועד 7 בינואר; Standard בשאר השנה.
- מאפשרת לשמוע כל MP3.
- מעתיקה את צלילי החבילה הנבחרת אל Notifications/Discord Sounds כך שניתן לבחור אותם ידנית בהגדרות הצליל של Android/WhatsApp.

מה היא לא יכולה לעשות:
- אינה מחליפה בעצמה את צלילי המענה/ניתוק הפנימיים של WhatsApp.
- אינה יכולה לשנות ללא אישור את הגדרות ערוצי ההתראות של WhatsApp. לאחר העתקה יש לבחור את הצליל בהגדרות Android/WhatsApp.
- אינה משנה את הצלילים אצל אנשים אחרים.

איך לבנות APK במחשב:
1. התקן Android Studio עדכני עם Android SDK 35 ו-JDK 17.
2. חלץ את ZIP הפרויקט.
3. פתח ב-Android Studio את התיקייה WhatsAppDiscordSoundsApp.
4. המתן ל-Gradle Sync.
5. בחר Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio יציג קישור למיקום ה-APK.

דרישות: Android 10 (API 29) ומעלה.
