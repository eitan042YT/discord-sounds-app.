WhatsApp Discord Sounds – פרויקט Android
========================================

זהו פרויקט מקור לאפליקציית Android, לא קובץ APK מוכן. בסביבת היצירה אין Android SDK/Gradle ולכן לא ניתן לקמפל כאן APK אמיתי.

מה האפליקציה עושה:
- מציגה חבילות Standard / Halloween / Winter / Extras.
- בוחרת חבילה מומלצת לפי תאריך: Halloween באוקטובר ועד 1 בנובמבר; Winter בדצמבר ועד 7 בינואר; Standard בשאר השנה.
- מאפשרת לשמוע כל MP3.
- מאזינה להתראות WhatsApp: הודעה חדשה מפעילה צליל הודעה חלופי.
- אם Android מדווח על התראה בקטגוריית שיחה, צליל השיחה הנבחר מתנגן בלולאה עד שההתראה מוסרת.
- מעתיקה את צלילי החבילה הנבחרת אל Notifications/Discord Sounds כך שניתן לבחור אותם ידנית בהגדרות הצליל של Android/WhatsApp.

מה היא לא יכולה לעשות:
- אינה מחליפה בעצמה את כל הצלילים הפנימיים של WhatsApp. חיוג יוצא, מענה, ניתוק, השתקה והמתנה אינם זמינים באופן אמין דרך NotificationListenerService.
- אינה יכולה להשתיק בעצמה את WhatsApp או לשנות את ערוצי ההתראות שלו. אם רוצים למנוע צליל כפול, יש להשתיק ידנית את צלילי ההתראות המתאימים בהגדרות WhatsApp/Android; אין לכבות את ההתראות עצמן.
- אינה משנה את הצלילים אצל אנשים אחרים.

איך לבנות APK במחשב:
1. התקן Android Studio עדכני עם Android SDK 35 ו-JDK 17.
2. חלץ את ZIP הפרויקט.
3. פתח ב-Android Studio את התיקייה WhatsAppDiscordSoundsApp.
4. המתן ל-Gradle Sync.
5. בחר Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio יציג קישור למיקום ה-APK.

דרישות: Android 10 (API 29) ומעלה.
