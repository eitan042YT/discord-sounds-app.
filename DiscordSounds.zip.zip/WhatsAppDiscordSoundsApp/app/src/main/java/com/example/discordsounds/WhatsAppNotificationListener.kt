package com.example.discordsounds

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Plays replacement sounds for WhatsApp notifications that Android exposes to
 * NotificationListenerService. A call-category notification is treated as an
 * active call event: the selected call sound loops until that notification is
 * removed. This cannot observe every in-app WhatsApp sound or every call state.
 */
class WhatsAppNotificationListener : NotificationListenerService() {
    private var player: MediaPlayer? = null
    private var activeCallNotificationKey: String? = null
    private val seenMessages = LinkedHashSet<String>()

    override fun onListenerConnected() {
        super.onListenerConnected()
        // Recover an already-active WhatsApp call after Android reconnects the listener.
        activeNotifications?.firstOrNull { isWhatsApp(it.packageName) && isCallNotification(it) }
            ?.let { startCallSound(it) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!isWhatsApp(sbn.packageName)) return

        if (isCallNotification(sbn)) {
            startCallSound(sbn)
            return
        }

        // Play one short replacement sound for each newly posted notification.
        val key = sbn.key
        if (!seenMessages.add(key)) return
        if (seenMessages.size > 300) seenMessages.clear()

        val prefs = getSharedPreferences("sound_settings", MODE_PRIVATE)
        val pack = prefs.getString("pack", "Standard") ?: "Standard"
        val file = prefs.getString("message_sound", null) ?: return
        playAsset("sounds/$pack/$file", loop = false)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        seenMessages.remove(sbn.key)
        if (sbn.key == activeCallNotificationKey) {
            activeCallNotificationKey = null
            stopPlayer()
        }
    }

    private fun isWhatsApp(pkg: String): Boolean =
        pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"

    private fun isCallNotification(sbn: StatusBarNotification): Boolean =
        sbn.notification.category == android.app.Notification.CATEGORY_CALL

    private fun startCallSound(sbn: StatusBarNotification) {
        // Do not restart the loop every time WhatsApp updates the same call notification.
        if (activeCallNotificationKey == sbn.key && player != null) return
        activeCallNotificationKey = sbn.key

        val prefs = getSharedPreferences("sound_settings", MODE_PRIVATE)
        val pack = prefs.getString("pack", "Standard") ?: "Standard"
        val file = prefs.getString("call_sound", null) ?: return
        playAsset("sounds/$pack/$file", loop = true, ringtone = true)
    }

    private fun playAsset(path: String, loop: Boolean, ringtone: Boolean = false) {
        stopPlayer()
        try {
            val afd = assets.openFd(path)
            val newPlayer = MediaPlayer()
            player = newPlayer
            newPlayer.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(if (ringtone) AudioAttributes.USAGE_NOTIFICATION_RINGTONE else AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            newPlayer.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            newPlayer.isLooping = loop
            newPlayer.setOnPreparedListener { prepared ->
                if (player === prepared) prepared.start() else prepared.release()
            }
            newPlayer.setOnCompletionListener { completed ->
                if (player === completed) {
                    player = null
                    completed.release()
                }
            }
            newPlayer.setOnErrorListener { failed, _, _ ->
                if (player === failed) player = null
                failed.release()
                true
            }
            newPlayer.prepareAsync()
        } catch (e: Exception) {
            Log.e("WhatsAppSound", "Could not play $path", e)
            stopPlayer()
        }
    }

    private fun stopPlayer() {
        val old = player
        player = null
        try {
            if (old != null) {
                if (old.isPlaying) old.stop()
                old.release()
            }
        } catch (_: Exception) {
            // Player may already have been released after an asynchronous error.
        }
    }

    override fun onDestroy() {
        stopPlayer()
        activeCallNotificationKey = null
        super.onDestroy()
    }
}
