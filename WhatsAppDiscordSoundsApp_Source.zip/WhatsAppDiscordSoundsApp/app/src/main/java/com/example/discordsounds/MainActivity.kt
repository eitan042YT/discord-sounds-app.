package com.example.discordsounds

import android.app.Activity
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.content.ContentValues
import android.view.Gravity
import android.widget.*
import java.time.LocalDate

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var selectedPack = "Standard"
    private lateinit var status: TextView
    private lateinit var list: LinearLayout

    private fun seasonalPack(): String {
        val d = LocalDate.now()
        return when {
            (d.monthValue == 10) || (d.monthValue == 11 && d.dayOfMonth == 1) -> "Halloween"
            (d.monthValue == 12) || (d.monthValue == 1 && d.dayOfMonth <= 7) -> "Winter"
            else -> "Standard"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedPack = seasonalPack()
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 28) }
        scroll.addView(page)
        page.addView(TextView(this).apply { text = "WhatsApp Discord Sounds"; textSize = 24f })
        page.addView(TextView(this).apply { text = "בחר חבילת צלילים, שמע תצוגה מקדימה והעתק אותה לתיקיית ההתראות של Android."; textSize = 15f; setPadding(0,12,0,16) })
        status = TextView(this).apply { textSize = 14f; setPadding(0,8,0,12) }
        page.addView(status)
        val packs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("Standard", "Halloween", "Winter", "Extras", "אוטומטי").forEach { label ->
            val b = Button(this).apply { text = label; textSize = 10f; setOnClickListener { selectedPack = if(label == "אוטומטי") seasonalPack() else label; refresh() } }
            packs.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        page.addView(packs)
        page.addView(Button(this).apply { text = "העתק את החבילה הנבחרת להתראות"; setOnClickListener { installPack() } })
        page.addView(TextView(this).apply { text = "צלילים בחבילה:"; textSize = 18f; setPadding(0,16,0,8) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(list)
        page.addView(TextView(this).apply { text = "הערה: האפליקציה מעתיקה צלילים לתיקיית Notifications כדי שתוכל לבחור אותם בהגדרות Android/WhatsApp. היא לא יכולה לשנות בעצמה את כל צלילי השיחה הפנימיים של WhatsApp או את ערוצי ההתראות שלו."; textSize = 13f; setPadding(0,20,0,12) })
        setContentView(scroll)
        refresh()
    }

    private fun names(pack: String): List<String> = try { assets.list("sounds/$pack")?.filter { it.endsWith(".mp3") }?.sorted() ?: emptyList() } catch (_: Exception) { emptyList() }

    private fun refresh() {
        status.text = "חבילה נבחרת: $selectedPack | בחירה אוטומטית לפי תאריך: ${seasonalPack()}"
        list.removeAllViews()
        names(selectedPack).forEach { file ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = file.removeSuffix(".mp3"); textSize = 14f }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply { text = "▶"; setOnClickListener { play(selectedPack, file) } })
            list.addView(row)
        }
        if (names(selectedPack).isEmpty()) list.addView(TextView(this).apply { text = "אין קבצים בתיקייה הזו" })
    }

    private fun play(pack: String, file: String) {
        try {
            player?.release()
            val afd = assets.openFd("sounds/$pack/$file")
            player = MediaPlayer().apply { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length); prepare(); start(); setOnCompletionListener { it.release(); player = null } }
            afd.close()
        } catch (e: Exception) { Toast.makeText(this, "לא ניתן לנגן: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun installPack() {
        val files = names(selectedPack)
        if (files.isEmpty()) { Toast.makeText(this, "אין צלילים בחבילה", Toast.LENGTH_SHORT).show(); return }
        var count = 0
        files.forEach { file ->
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, "Discord_${selectedPack}_$file")
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
                    put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_NOTIFICATIONS + "/Discord Sounds")
                    put(MediaStore.Audio.Media.IS_NOTIFICATION, 1)
                }
                val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out -> assets.open("sounds/$selectedPack/$file").use { input -> input.copyTo(out) } }
                    count++
                }
            } catch (_: Exception) { }
        }
        Toast.makeText(this, "הועתקו $count מתוך ${files.size} צלילים. עכשיו בחר אותם בהגדרות הצליל של Android/WhatsApp.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
